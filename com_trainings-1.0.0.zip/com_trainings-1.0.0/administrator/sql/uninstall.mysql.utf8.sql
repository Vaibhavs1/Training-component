DROP TABLE IF EXISTS `#__trainings_list`;
DROP TABLE IF EXISTS `#__trainings_faq`;
DROP TABLE IF EXISTS `#__trainer_details`;

